# Tribute to the donut

A Pen created on CodePen.io. Original URL: [https://codepen.io/MatteoPeroniDev/pen/XWyJoNW](https://codepen.io/MatteoPeroniDev/pen/XWyJoNW).

Indulge your sweet tooth and pay homage to the beloved treat with "Tribute to the Donut," a delightful CodePen creation that celebrates the iconic pastry in all its glory. Immerse yourself in a world of mouthwatering visuals and interactive elements that capture the essence of this beloved dessert. From sprinkles to glazes, explore the colorful and delectable world of donuts through captivating animations and playful interactions.
I used Three.js to render and animate the model and css to style the two titles and the background.